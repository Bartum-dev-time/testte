﻿namespace API_RestCurrencyConverter.Models
{
	public enum EState
	{
		Aceptado,
		Rechazado,
		Abortado
	}
}
